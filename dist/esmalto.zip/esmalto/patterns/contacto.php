<?php
/**
 * Title: Contacto (datos + formulario)
 * Slug: esmalto/contacto
 * Categories: esmalto, contact
 * Keywords: contacto, formulario, dirección, teléfono, email
 * Viewport Width: 1400
 * Description: Datos de contacto, enlaces útiles y el formulario de contacto de WPForms.
 */
?>
<!-- wp:group {"align":"full","className":"esm-seccion","style":{"spacing":{"padding":{"top":"clamp(32px, 5vw, 48px)","right":"clamp(16px, 4vw, 40px)","bottom":"clamp(60px, 9vw, 110px)","left":"clamp(16px, 4vw, 40px)"}}},"layout":{"type":"constrained","contentSize":"1280px"}} -->
<div class="wp-block-group alignfull esm-seccion" style="padding-top:clamp(32px, 5vw, 48px);padding-right:clamp(16px, 4vw, 40px);padding-bottom:clamp(60px, 9vw, 110px);padding-left:clamp(16px, 4vw, 40px)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"clamp(28px, 4vw, 56px)"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"style":{"spacing":{"blockGap":"22px"}}} -->
<div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"blockGap":"8px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"is-style-antetitulo"} -->
<p class="is-style-antetitulo">Dirección</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"1.65"}}} -->
<p style="line-height:1.65">Esmalto Cerámica<br>Kumen Tres Sesenta, S.L.<br>C/ Bolsa, 44<br>11540 Sanlúcar de Barrameda (Cádiz)<br>NIF B88655014</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"8px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"is-style-antetitulo"} -->
<p class="is-style-antetitulo">Teléfono</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="tel:+34614051042">+34 614 05 10 42</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"8px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"is-style-antetitulo"} -->
<p class="is-style-antetitulo">Horario</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lunes a viernes, de 9:00 a 14:00 y de 16:00 a 19:00</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"8px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"is-style-antetitulo"} -->
<p class="is-style-antetitulo">Email</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="mailto:hola@esmalto.com">hola@esmalto.com</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"8px"}},"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"is-style-antetitulo"} -->
<p class="is-style-antetitulo">Enlaces útiles</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"esm-enlaces-destacados"} -->
<ul class="wp-block-list esm-enlaces-destacados"><!-- wp:list-item -->
<li><a href="/gastos-de-envio/">Cómo calcular gastos de envío</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="/muestras/">Muestras</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"esm-mapa","style":{"dimensions":{"minHeight":"320px"},"border":{"color":"rgba(255,255,255,0.1)","width":"1px"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center","verticalAlignment":"center"}} -->
<div class="wp-block-group esm-mapa has-border-color" style="border-color:rgba(255,255,255,0.1);border-width:1px;min-height:320px"><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="https://www.google.com/maps/search/?api=1&amp;query=C%2F+Bolsa+44%2C+11540+Sanl%C3%BAcar+de+Barrameda" target="_blank" rel="noreferrer noopener">Cómo llegar (Google Maps)</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"padding":{"top":"clamp(24px, 4vw, 40px)","right":"clamp(24px, 4vw, 40px)","bottom":"clamp(24px, 4vw, 40px)","left":"clamp(24px, 4vw, 40px)"}},"border":{"color":"rgba(255,255,255,0.1)","width":"1px"}},"backgroundColor":"superficie","layout":{"type":"default"}} -->
<div class="wp-block-group has-border-color has-superficie-background-color has-background" style="border-color:rgba(255,255,255,0.1);border-width:1px;padding-top:clamp(24px, 4vw, 40px);padding-right:clamp(24px, 4vw, 40px);padding-bottom:clamp(24px, 4vw, 40px);padding-left:clamp(24px, 4vw, 40px)"><!-- wp:paragraph {"className":"is-style-antetitulo"} -->
<p class="is-style-antetitulo">Formulario de contacto</p>
<!-- /wp:paragraph -->

<!-- wp:shortcode -->
[esmalto_formulario tipo="contacto"]
<!-- /wp:shortcode --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
